import React from 'react';

const Footer = () => {
    return (
        <div>
            <p className='text-center text-danger mt-4'>This Website Copyright By Joy Shil</p>
        </div>
    );
};

export default Footer;