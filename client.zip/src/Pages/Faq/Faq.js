import React from 'react';

const Faq = () => {
    return (
        <div>
            <h2 className='text-center text-primary'>This is FAQ Section</h2>
        </div>
    );
};

export default Faq;